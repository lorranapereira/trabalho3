class DAO:
    def __init__(self):
        self._dados_con = "dbname=banco host=localhost port=5432 user=postgres  "
    